from menu import display_menu
from contact import add_contact
from contact import view_contact
from file_handler import load_contacts_from_file, save_contact_to_file 
from contact import remove_contact
from contact import search_contact

def main():
    contacts = load_contacts_from_file()
    while True:
        choice = display_menu()
        if choice == "1":
            add_contact(contacts)
        elif choice == "2":
            view_contact(contacts)
        elif choice == "3":
            remove_contact(contacts)
        elif choice == "4":
            search_contact(contacts)
        elif choice == "5":
            save_contact_to_file(contacts)
            print("Good Bye!")
            break
        else:
            print(f"Please choose an option{choice}")
            
            
if __name__ == "__main__":
    main()
        
        