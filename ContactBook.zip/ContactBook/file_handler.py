import json

def load_contacts_from_file(filename="contacts.json"):
    try:
        with open(filename, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return []
    except json.JSONDecodeError:
        print("Error reading file. Starting with an empty contact list.")
        return []
    

def save_contact_to_file(contacts, filename="contacts.json"):
    with open(filename, "w") as file:
        json.dump(contacts, file, indent=4)
        print("Contacts saved succesfully!")
        
    