def add_contact(contacts):
    name = input("Enter contact name: ")
    if not name.isalpha():
        print("Invalid name. It must contain only letters")
        return
    
    try:
        phone = int(input("Enter phone number: "))
    except ValueError:
        print("Phone number must be an integer.")
        return
    
    for contact in contacts:
        if contact["phone"] == phone:
            print("The phone number already exists.")
            return
        
    email = input("Enter email: ")
    address = input("Enter address: ")
    contacts.append({"name": name, "phone": phone, "email": email, "address": address})
    print("Contact added succesfully!")
    
    
def view_contact(contacts):
    if not contacts:
        print("No contacts to display")
        return
        
        print("\n--- Contact List ---")
    for idx, contact in enumerate(contacts, start=1):
        print(f"{idx}. Name: {contact['name']}, Phone: {contact['phone']}, Email: {contact['email']}, Address: {contact['address']}")
        
    
    
def remove_contact(contacts):
    if not contacts:
        print("No contacts to remove")
        return
    
    try:
        phone = int(input("Enter the phone number you want to remove: "))
    except ValueError:
        print("Phone number must be an integer.")
        return
    
    for contact in contacts:
        if contact["phone"] == phone:
            contacts.remove(contact)
            print("Contact removed succesfully!")
            return
        
    print("No contacts found with this phone number.")
    
    
def search_contact(contacts):
    if not contacts:
        print("No contacts to search.")
        return
    
    
    query = input("Enter search item: ").lower()
    results = [contact for contact in contacts if query in contact['name'].lower() or
               query in str(contact['phone']) or
               query in contact['email'].lower() or
               query in contact['address'].lower()]

    if results:
        print("\n--- Search Results ---")
        for idx, contact in enumerate(results, start=1):
            print(f"{idx}. Name: {contact['name']}, Phone: {contact['phone']}, Email: {contact['email']}, Address: {contact['address']}")
    else:
        print("No contacts found.")